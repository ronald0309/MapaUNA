/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package files;

import controller.Utiles;
import graphs.Graph;
import java.awt.Image;
import java.awt.geom.Point2D;
import java.io.File;
import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

enum VARIABLES {
    VERTEX("vertex"),
    INFO("info"),
    X("x"),
    Y("y"),
    DISTANCIA("distancia"),
    PREDECESOR("predecesor"),
    EDGE("edge"),
    TAIL("tail"),
    HEAD("head"),
    FILE_NAME("datos"),
    FILE_TITLE("datos"),
    XML_EXTENSION(".xml"),
    IMAGE("image"),
    IMAGE_NAME("background.png");

    private final String value;

    VARIABLES(String envUrl) {
        this.value = envUrl;
    }

    public String getValue() {
        return value;
    }
}

public class Archivo {

    public static <V, W> Graph<V, W> read(Utiles<String, V> convertToV, Utiles<String, W> convertToW, String ubicacion) throws Exception {
        Graph<V, W> graph = new Graph();
        ubicacion = (ubicacion == null) ? VARIABLES.FILE_NAME.getValue() + VARIABLES.XML_EXTENSION.getValue() : ubicacion;
        try {
            File archivo = new File(ubicacion);

            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(archivo);
            doc.getDocumentElement().normalize();

            NodeList as = doc.getElementsByTagName(VARIABLES.VERTEX.getValue());

            for (int i = 0; i < as.getLength(); i++) {
                Node n = as.item(i);

                if (n.getNodeType() == Node.ELEMENT_NODE) {
                    Element a = (Element) n;

                    graph.add(
                            convertToV.apply(
                                    a.getAttribute(VARIABLES.INFO.getValue())
                            ),
                            new Point2D.Float(
                                    Float.parseFloat(a.getAttribute(VARIABLES.X.getValue())),
                                    Float.parseFloat(a.getAttribute(VARIABLES.Y.getValue()))
                            )
                    );
                }
            }
            as = doc.getElementsByTagName(VARIABLES.EDGE.getValue());
            for (int i = 0; i < as.getLength(); i++) {
                Node n = as.item(i);
                if (n.getNodeType() == Node.ELEMENT_NODE) {
                    Element a = (Element) n;
                    graph.add(
                            convertToV.apply(
                                    a.getAttribute(VARIABLES.TAIL.getValue())
                            ), convertToV.apply(
                            a.getAttribute(VARIABLES.HEAD.getValue())
                    ), convertToW.apply(
                            a.getAttribute(VARIABLES.INFO.getValue())
                    )
                    );
                }
            }
            as = doc.getElementsByTagName(VARIABLES.IMAGE.getValue());

            for (int i = 0; i < as.getLength(); i++) {
                Node n = as.item(i);
                if (n.getNodeType() == Node.ELEMENT_NODE) {
                    Element a = (Element) n;
                    graph.setBackground(
                            a.getAttribute(VARIABLES.IMAGE.getValue())
                    );
                }
            }

        } catch (IOException | NumberFormatException | ParserConfigurationException | SAXException ex) {
            throw new Exception(ex.getMessage());
        }

        return graph;
    }

    public static <V, W> void save(Graph<V, W> graph, String ruta) throws Exception {
        try {
            DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docFactory.newDocumentBuilder();

            Document doc = docBuilder.newDocument();
            Element rootElement = doc.createElement(VARIABLES.FILE_TITLE.getValue());
            doc.appendChild(rootElement);

            //Para recorrer el HashMap
            /*graph.getAllVertices().forEach((vertex) -> {
                Element nodo = doc.createElement(VARIABLES.VERTEX.getValue());
                rootElement.appendChild(nodo);

                nodo.setAttributeNode(createAtribute(doc, VARIABLES.INFO.getValue(), vertex.getInfo()));
                //Position{
                nodo.setAttributeNode(createAtribute(doc, VARIABLES.X.getValue(), vertex.getPosition().getX()));
                nodo.setAttributeNode(createAtribute(doc, VARIABLES.Y.getValue(), vertex.getPosition().getY()));
                //}
            });*/
            for (int i = 0; i < graph.getAllVertices().count(); i++) {
                Element nodo = doc.createElement(VARIABLES.VERTEX.getValue());
                rootElement.appendChild(nodo);

                nodo.setAttributeNode(createAtribute(doc, VARIABLES.INFO.getValue(), graph.getAllVertices().get(i).getInfo()));
                //Position{
                nodo.setAttributeNode(createAtribute(doc, VARIABLES.X.getValue(), graph.getAllVertices().get(i).getPosition().getX()));
                nodo.setAttributeNode(createAtribute(doc, VARIABLES.Y.getValue(), graph.getAllVertices().get(i).getPosition().getY()));
                //}
            }

            for (int i = 0; i < graph.getAllEdges().count(); i++) {
                Element nodo = doc.createElement(VARIABLES.EDGE.getValue());
                rootElement.appendChild(nodo);

                nodo.setAttributeNode(createAtribute(doc, VARIABLES.TAIL.getValue(), graph.getAllEdges().get(i).getTail().getInfo()));
                nodo.setAttributeNode(createAtribute(doc, VARIABLES.HEAD.getValue(), graph.getAllEdges().get(i).getHead().getInfo()));
                nodo.setAttributeNode(createAtribute(doc, VARIABLES.INFO.getValue(), graph.getAllEdges().get(i).getInfo()));
            }

            Element nodo = doc.createElement(VARIABLES.IMAGE.getValue());
            rootElement.appendChild(nodo);
//            nodo.setAttributeNode(createAtribute(doc, VARIABLES.IMAGE.getValue(), VARIABLES.IMAGE_NAME.getValue()));
            nodo.setAttributeNode(createAtribute(doc, VARIABLES.IMAGE.getValue(), graph.getBackground()));

            /*graph.getAllEdges().forEach((edge) -> {
                Element nodo = doc.createElement(VARIABLES.EDGE.getValue());
                rootElement.appendChild(nodo);

                nodo.setAttributeNode(createAtribute(doc, VARIABLES.TAIL.getValue(), edge.getTail().getInfo()));
                nodo.setAttributeNode(createAtribute(doc, VARIABLES.HEAD.getValue(), edge.getHead().getInfo()));
                nodo.setAttributeNode(createAtribute(doc, VARIABLES.INFO.getValue(), edge.getInfo()));
            });*/
            //Para escribir el contenido en un archivo .xml
            Source source = new DOMSource(doc);
            Transformer transformer = TransformerFactory.newInstance().newTransformer();

            String r = (ruta == null || ruta.isEmpty()) ? VARIABLES.FILE_NAME.getValue() : ruta;
            r = (!r.contains(VARIABLES.XML_EXTENSION.getValue())) ? r + VARIABLES.XML_EXTENSION.getValue() : r;

            transformer.transform(source, new StreamResult(new java.io.File(r)));
        } catch (ParserConfigurationException | TransformerException ex) {
            throw new Exception(ex.getMessage());
        }
    }

    public static <V> Attr createAtribute(Document doc, String name, V value) {
        Attr attr = doc.createAttribute(name);
        attr.setValue(String.valueOf(value));
        return attr;
    }

}
