
package controller;

import java.util.function.Consumer;
import java.util.function.Function;

public class Utiles<V, W> {
    Function<V, W> function;
    Consumer<Exception> consumidor;
    
    public Utiles(Function<V, W> funcion, Consumer<Exception> consumidor){
        this.function = funcion;
        this.consumidor = consumidor;
    }
    
    public W apply(V parameter){
        W value = null;
        try{
            value = (W)function.apply(parameter);
            if(value == null){
                throw new Exception("Valor nulo");
            }
        }catch(Exception ex){
            consumidor.accept(ex);
        }
        return value;
    }
}
