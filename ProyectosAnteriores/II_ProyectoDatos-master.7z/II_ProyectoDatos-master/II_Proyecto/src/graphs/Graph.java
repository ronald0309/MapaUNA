package graphs;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Stroke;
import java.awt.Toolkit;
import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.Observable;
import javax.imageio.ImageIO;
import lists.Iterator;
import lists.List;
import lists.Queue;
import lists.SimpleLinkedList;

public class Graph<V, E> {

    public Graph() {
        this.vertices = new SimpleLinkedList<>();
        this.edges = new SimpleLinkedList<>();
        this.active = false;
        this.m = new SimpleLinkedList<>();

    }

    public GVertex<V> getVertex(V v) {
        GVertex<V> r = null;
        Iterator<GVertex<V>> i = vertices.getIterator();
        while (i.hasNext()) {
            GVertex<V> t = i.getNext();
            if (t.getInfo().equals(v)) {
                r = t;
                break;
            }
        }
        return r;
    }

    public List<GVertex<V>> getAdjacent(GVertex<V> v) {
        List<GVertex<V>> r = new SimpleLinkedList<>();
        Iterator<Edge<V, E>> i = edges.getIterator();
        while (i.hasNext()) {
            Edge<V, E> e = i.getNext();
            if (e.getHead().getInfo().equals(v.getInfo())) {
                r.addLast(e.getTail());
            }
            if (e.getTail().getInfo().equals(v.getInfo())) {
                r.addLast(e.getHead());
            }
        }
        return r;
    }

    public void add(V v, Point2D.Float position) {
        vertices.addLast(new GVertex<>(v, position));
    }

    public void add(V v) {
        vertices.addLast(new GVertex<>(v, new Point2D.Float(DX + df.x, DY + df.y)));

        if (px < MX) {
            df.x += DX;
            px++;
        } else {
            df.x = 0;
            df.y += DY;
            px = 0;
        }
    }

    public GVertex<V> getGVertex(Point2D.Float position) {
        GVertex<V> v = null;
        Iterator<GVertex<V>> ite = vertices.getIterator();
        while (ite.hasNext()) {
            GVertex<V> aux = ite.getNext();
            if ((aux.getPosition().getX() + 30) > position.getX()
                    && aux.getPosition().getX() < (position.getX() + 80)
                    && (aux.getPosition().getY() + 30) > position.getY()
                    && aux.getPosition().getY() < position.getY() + 80) {
                v = aux;
                break;
            }
        }
        return v;
    }

    public void add(GVertex<V> tail, GVertex<V> head, E w) {
        if ((tail == null) || (head == null)) {
            throw new NullPointerException("No existe el vértice.");
        }
        edges.addLast(new Edge<>(tail, head, w));
    }

    public void add(V t, V h, E w) {
        add(getVertex(t), getVertex(h), w);
    }

    public void add(V t, V h, E w, boolean bothDirections) {
        if (bothDirections) {
            add(getVertex(t), getVertex(h), w);
            add(getVertex(h), getVertex(t), w);
        } else {
            add(getVertex(t), getVertex(h), w);
        }
    }

    public List<GVertex<V>> getAllVertices() {
        return vertices;
    }

    public List<Edge<V, E>> getAllEdges() {
        return edges;
    }

    public void init(GVertex<V> pathStart, GVertex<V> pathEnd) {
        runner = new Thread(() -> {
            run(pathStart, pathEnd);
        });
        runner.start();
    }

    public void run(GVertex<V> pathStart, GVertex<V> pathEnd) {
        // Calcula la posición inicial del marcador..
        Marker marker = new Marker(pathStart, pathStart, pathEnd);
        m.addLast(marker);

        // Al principio, el marcador se encuentra
        // detenido en la posición del primer vértice.
        while (runner == Thread.currentThread()) {

            if (isActive()) {
                for (int i = 0; i < m.count(); i++) {
                    updateMarker(m.get(i), m.get(i).getEndPathVertex());
                }

            } else {
                //System.out.println("Modelo inactivo..");
            }
            try {
                Thread.sleep(MAX_WAIT);
            } catch (InterruptedException ex) {
            }
        }
    }

    private void updateMarker(Marker m, GVertex<V> pathEnd) {
        if (m.isMoving()) {
            m.move();
        } else {

            // Si el marcador no está en movimiento,
            // es porque se encuentra sobre uno de los
            // vértices. Se debe calcular entonces
            // la posición del siguiente vértice.
            synchronized (Graph.this) {

                GVertex<V> v0 = m.getEndVertex();
                List<GVertex<V>> vs = getShortestPath(v0, pathEnd);
                //System.err.println(v0);
                //List<GVertex<V>> vs = getShortestPath(v0, pathEnd); 
                //System.out.println(vs);

                // Se define el criterio para seleccionar
                // el siguiente vértice.
                try {
                    GVertex<V> v1 = vs.get(1);
                    m.setStartVertex(v0);
                    m.setEndVertex(v1);
                    m.recalculateVelocity();
                    m.start();

                } catch (IndexOutOfBoundsException ex) {
                    //(en este momento ha llegado a su destino)
                    //eliminar la imagen del repartidor? 
                }
            }
        }
    }

    public void dijkstraShortestPathAlgorithm(GVertex<V> origen) {
        Queue<GVertex<Integer>> toEvaluate = new SimpleLinkedList<>();
        ArrayList<GVertex<Integer>> closedList = new ArrayList<>();
        boolean flag = true;

        for (int i = 0; i < vertices.count(); i++) {
            GVertex<Integer> aux = (GVertex<Integer>) vertices.get(i);
            if (aux.equals(origen)) {
                aux.setDistance(0.0);
                aux.setPredecessor(null);
                toEvaluate.enqueue(aux);
            } else {
                aux.setDistance(Double.MAX_VALUE);
                aux.setPredecessor(null);
            }
        }

        while (!toEvaluate.isEmpty()) {
            GVertex<Integer> evaluating = toEvaluate.dequeue();

            List<GVertex<V>> l = getAdjacent((GVertex<V>) evaluating);

            for (int i = 0; i < l.count(); i++) {

                GVertex<Integer> aux = (GVertex<Integer>) l.get(i);
                if (theresRelation((GVertex<V>) evaluating, (GVertex<V>) aux) != null) {
                    Edge<GVertex<V>, Double> edge = theresRelation((GVertex<V>) evaluating, (GVertex<V>) aux);
                    if (aux.getDistance() > evaluating.getDistance() + edge.getInfo()) {
                        aux.setDistance(evaluating.getDistance() + edge.getInfo());
                        aux.setPredecessor(evaluating);
                    }

                    /*Agregar a toEvaluate si no esta en closedList*/
                    if (!isInThere(aux, closedList)) {
                        toEvaluate.enqueue((GVertex<Integer>) aux);
                    }
                }

            }

            closedList.add(evaluating);

        }

    }

    public List<GVertex<V>> getShortestPath(GVertex<V> origen, GVertex<V> destino) {

        List<GVertex<V>> shortestPath = new SimpleLinkedList<>();

        dijkstraShortestPathAlgorithm(origen);

        while (destino != null) {

            shortestPath.addFirst(destino);
            destino = destino.getPredecessor();
        }

        return shortestPath;
    }

    public Edge<GVertex<V>, Double> theresRelation(GVertex<V> tail, GVertex<V> head) {
        for (int i = 0; i < edges.count(); i++) {
            if (edges.get(i).getTail().equals(tail) && edges.get(i).getHead().equals(head)) {
                return (Edge<GVertex<V>, Double>) edges.get(i);
            }
        }
        return null;
    }

    private boolean isInThere(GVertex<Integer> node, ArrayList<GVertex<Integer>> array) {
        for (int i = 0; i < array.size(); i++) {
            if (array.get(i).getInfo().equals(node.getInfo())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public String toString() {
        return String.format("G: (%n   V: %s,%n   E: %s%n)",
                vertices, edges);
    }

    public Rectangle getBounds() {
        float x0, x1, y0, y1;
        x0 = x1 = y0 = y1 = 0f;
        boolean f = false;

        Iterator<GVertex<V>> i = vertices.getIterator();
        while (i.hasNext()) {
            GVertex<V> v = i.getNext();

            if (!f) {
                x0 = x1 = v.getPosition().x;
                y0 = y1 = v.getPosition().y;
            }
            f = true;

            x0 = Math.min(x0, v.getPosition().x);
            x1 = Math.max(x1, v.getPosition().x);
            y0 = Math.min(y0, v.getPosition().y);
            y1 = Math.max(y1, v.getPosition().y);
        }

        if (!f) {
            throw new IllegalArgumentException();
        }

        Rectangle r = new Rectangle(
                (int) (x0), (int) (y0),
                (int) (x1 - x0), (int) (y1 - y0)
        );
        r.grow(S0 / 2, S0 / 2);
        return r;
    }

    public void paint(Graphics bg, Rectangle bounds, GVertex<V> anterior, GVertex<V> seleccionado) {
        Graphics2D g = (Graphics2D) bg;

        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        g.setColor(Color.DARK_GRAY);
        g.setStroke(GUIDE_STROKE);
        Rectangle b = getBounds();
        g.drawRect(b.x, b.y, b.width, b.height);

        g.setFont(BASE_FONT);
        FontMetrics fm = g.getFontMetrics();

        Iterator<Edge<V, E>> i = edges.getIterator();
//        while (i.hasNext()) {
//            
//            /*LO QUE MAS PUEDE ASEMEJARSE(SIMULAR) EL CAMINO (LA CALLE)*/
//            Edge<V, E> e = i.getNext();
//            g.setStroke(BASE_STROKE);
//            g.setColor(Color.magenta);
//
//            g.drawLine(
//                    (int) e.getTail().getPosition().x,
//                    (int) e.getTail().getPosition().y,
//                    (int) e.getHead().getPosition().x,
//                    (int) e.getHead().getPosition().y
//            );
//
//            /*LINEAS MUY FINAS QUE CONECTAN NODOS (DENTRO DE LA "CALLE")*/
//            g.setStroke(new BasicStroke(1f));
//            g.setColor(Color.BLACK);
//
//            g.drawLine(
//                    (int) e.getTail().getPosition().x,
//                    (int) e.getTail().getPosition().y,
//                    (int) e.getHead().getPosition().x,
//                    (int) e.getHead().getPosition().y
//            );
//        }

        g.setStroke(VERTEX_STROKE);
        Iterator<GVertex<V>> j = vertices.getIterator();
        while (j.hasNext()) {
            GVertex<V> v = j.getNext();

            g.setColor(Color.GRAY);
            g.fillOval((int) v.getPosition().x - S0 / 2 + 4,
                    (int) v.getPosition().y - S0 / 2 + 4,
                    S0, S0);
            g.setColor(Color.WHITE);
            g.fillOval((int) v.getPosition().x - S0 / 2,
                    (int) v.getPosition().y - S0 / 2,
                    S0, S0);

                /*Borde del nodo*/
            if (v == anterior) {
                g.setColor(Color.BLACK);
            }else{
                g.setColor(Color.ORANGE);
            }
            g.drawOval((int) v.getPosition().x - S0 / 2,
                    (int) v.getPosition().y - S0 / 2,
                    S0, S0);

                /*ID(info) del nodo*/
            if (v == anterior) {
                g.setColor(Color.ORANGE);
            }else{
                g.setColor(Color.BLACK);
            }
            String t = String.format("%s", v.getInfo());
            g.drawString(t,
                    v.getPosition().x - fm.stringWidth(t),
                    v.getPosition().y + fm.getAscent());
        }

        if (!m.isEmpty()) {
            for (int k = 0; k < m.count(); k++) {
                m.get(k).paint(g);
            }
        }

//         g.setFont(INFO_FONT);
//         g.setColor(Color.BLACK);
//         g.drawString("velocidad constante", 32, 48);
//         g.drawString("(tiempo variable)", 32, 72);
    }

    public void update(Observable obs, Object evt) {
        throw new UnsupportedOperationException();
    }

    public String getAdjacencyInfo() {
        StringBuilder r = new StringBuilder();
        Iterator<GVertex<V>> i = vertices.getIterator();
        while (i.hasNext()) {
            GVertex<V> v = i.getNext();
            r.append(String.format("%s: ", v.getInfo()));
            Iterator<GVertex<V>> j = getAdjacent(v).getIterator();
            while (j.hasNext()) {
                r.append(String.format("%s, ", j.getNext().getInfo()));
            }
            r.append("\n");
        }
        return r.toString();
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public String getBackground() {
        return background;
    }

    public void setBackground(String url) {
        this.background = url;
    }

    private static final float[] DASHES = {4f, 4f};
    private static final Stroke BASE_STROKE
            = new BasicStroke(6f,
                    BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND, 0f, null, 0f); //Grueso de las aristas
    private static final Stroke VERTEX_STROKE = new BasicStroke(2f);

    private static final Stroke GUIDE_STROKE
            = new BasicStroke(1.0f,
                    BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL,
                    0f, DASHES, 0f);
    private static final Font BASE_FONT
            = new Font(Font.SANS_SERIF, Font.PLAIN, 24);
    private static final Font INFO_FONT
            = new Font(Font.SANS_SERIF, Font.PLAIN, 16);

    private static final int S0 = 18; //Tamano de los nodos

    private static final int DX = 72;
    private static final int DY = 64;
    private static final int MX = 6;
    private int px = 0;
    private Point2D.Float df = new Point2D.Float(0, 0);

    private final List<GVertex<V>> vertices;
    private final List<Edge<V, E>> edges;

    private static final int MAX_WAIT = 30; //Influye en la velocidad que se mueve el repartidor
    private boolean active = false;
    private Thread runner;
    
    private String background;

    private List<Marker> m; //Lista de repartidores
}
