package graphs;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.geom.Point2D;
import lists.SimpleLinkedList;
import lists.Stack;

class Marker<V> {

    public Marker(GVertex<V> startVertex, GVertex<V> endVertex, GVertex<V> endPathVertex) {
        this.startVertex = startVertex;
        this.endVertex = endVertex;
        this.startPosition = startVertex.getPosition();
        this.endPosition = endVertex.getPosition();
        this.endPathVertex = endPathVertex;
        this.dt = 0.0;
        this.t = 0.0;
        this.moving = false;
        this.background = Toolkit.getDefaultToolkit().createImage("src\\images\\repartidor.png");
        myShortestPath = new SimpleLinkedList<>();
    }

    public GVertex<V> getEndPathVertex() {
        return endPathVertex;
    }
    
    public void start() {
        t = 0.0;
        setMoving(true);
    }

    public Stack<GVertex<V>> getMyShortestPath() {
        return myShortestPath;
    }

    public void setMyShortestPath(Stack<GVertex<V>> myShortestPath) {
        this.myShortestPath = myShortestPath;
    }
    
    public void move() {
        if (moving = (t <= 1.0)) {
            t += dt;
        }
    }

    public void paint(Graphics2D g) {
        g.drawImage(background, (int) ((startPosition.x + t * (endPosition.x - startPosition.x)) - S1 / 2),
                (int) ((startPosition.y + t * (endPosition.y - startPosition.y)) - S1 / 2),
                S1, S1, null);
    }
    
    public GVertex<V> getStartVertex() {
        return startVertex;
    }

    public void setStartVertex(GVertex<V> startVertex) {
        this.startVertex = startVertex;
        this.startPosition = startVertex.getPosition();
    }

    public GVertex<V> getEndVertex() {
        return endVertex;
    }

    public void setEndVertex(GVertex<V> endVertex) {
        this.endVertex = endVertex;
        this.endPosition = endVertex.getPosition();
    }

    public void recalculateVelocity() {
        Point2D.Float p0 = startVertex.getPosition();
        Point2D.Float p1 = endVertex.getPosition();

        float dx = p1.x - p0.x;
        float dy = p1.y - p0.y;
        double dm = Math.sqrt(dx * dx + dy * dy);
        double dr = MIN_DR + Math.random() * (MAX_DR - MIN_DR);
        dt = dr / dm;
    }

    public boolean isMoving() {
        return moving;
    }

    public void setMoving(boolean moving) {
        this.moving = moving;
    }

    private static final int S1 = 60; // Influye en el tamano de la imagen del repartidor
    private static final double MIN_DR = 4.0;
    private static final double MAX_DR = 5.5;

    private GVertex<V> startVertex;
    private GVertex<V> endVertex;
    private Point2D.Float startPosition;
    private Point2D.Float endPosition;
    private  GVertex<V> endPathVertex;
    private double dt;
    private double t;
    private boolean moving;
    private Image background;
    
    private lists.Stack<GVertex<V>> myShortestPath;
}
