package graphs.view;

import graphs.GVertex;
import graphs.Graph;
import ii_proyecto.VentanaEjemplo;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Point2D;
import java.io.File;
import java.util.Vector;
import javax.imageio.ImageIO;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class GraphPanel<V, E> extends JPanel implements MouseListener {

    public GraphPanel(Graph<V, E> g) {
        this.g = g;
        this.background = Toolkit.getDefaultToolkit().createImage(g.getBackground());
        this.tmp = new JLabel("....................");
        this.addMouseListener(this);
        setup();
    }

    private void setup() {
        setBackground(Color.LIGHT_GRAY);
    }

    public void init() {
        runner = new Thread() {
            @Override
            public void run() {
                while (runner == Thread.currentThread()) {
                    repaint();
                    try {
                        Thread.sleep(MAX_WAIT);
                    } catch (InterruptedException ex) {
                    }
                }
            }

        };
        runner.start();
    }

    @Override
    public void paintComponent(Graphics bg) {
        super.paintComponent(bg);
        bg.drawImage(background, 0, 0, this);
        add(tmp);
        g.paint(bg, getBounds(), anterior, seleccionado);
    }

    public boolean isActive() {
        return g.isActive();
    }

    public void setActive(boolean state) {
        g.setActive(state);
    }
    
    public void setVentanaEjemplo(VentanaEjemplo ventana){
        this.ventana = ventana;
    }

    private static final int MAX_WAIT = 50;
    private Thread runner;
    private final Graph<V, E> g;
    
    private Image background;
    private JLabel tmp;
    
    private GVertex<V> anterior;
    private GVertex<V> seleccionado;
    
    private VentanaEjemplo<V,E> ventana;
    
    @Override
    public void mouseClicked(MouseEvent me) {
        try {
            if (!me.isMetaDown()) {

                if (me.getClickCount() >= 2) {

                    if (g.getGVertex(new Point2D.Float(me.getX(), me.getY())) != null){ throw (new Exception()); }
                    
                    ventana.repaint();
                }
                if (me.getClickCount() == 1) {
                    seleccionado = g.getGVertex(new Point2D.Float(me.getX(), me.getY()));
                    if(anterior == null){
                        anterior = seleccionado;
                        ventana.repaint();
                    
                    }else if(seleccionado == null || anterior == seleccionado){
                        anterior = null;
                        ventana.repaint();
                    
                    }else if(anterior != seleccionado){
                        ventana.addRoute(anterior, seleccionado);
                        anterior = null;
                        ventana.repaint();
                    }
                }
            }
        }
        catch(Exception ex){
            
        }
                  
                   
    }

    @Override
    public void mousePressed(MouseEvent e) {
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }

    @Override
    public void mouseEntered(MouseEvent e) {
    }

    @Override
    public void mouseExited(MouseEvent e) {
    }
}
