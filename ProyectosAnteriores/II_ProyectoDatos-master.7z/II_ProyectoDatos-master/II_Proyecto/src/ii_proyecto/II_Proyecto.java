/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ii_proyecto;

import controller.Utiles;
import files.Archivo;
import graphs.Graph;
import java.awt.geom.Point2D;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author Allan Ramirez
 */
public class II_Proyecto {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            JFrame.setDefaultLookAndFeelDecorated(true);
        } catch (ClassNotFoundException
                | IllegalAccessException
                | InstantiationException | UnsupportedLookAndFeelException ex) {
            System.err.printf("Excepción: '%s'%n", ex.getMessage());
        }

        new II_Proyecto().init();
    }

    public void init() {
        try {
            Graph<Integer, Double> g0;
            g0 = Archivo.<Integer, Double>read(
                    new Utiles<>(
                            (x) -> Integer.valueOf(x),
                            (Exception ex) -> ex.getMessage()
                    ),
                    new Utiles<>(
                            (x) -> Double.valueOf(x),
                            (Exception ex) -> ex.getMessage()
                    )
                    ,
                    null
            );

//            Graph<Integer, Double> g0 = crearPuntos();
//            Archivo.save(g0, null);
            //System.out.printf("%s%n%n", g0);
            //System.out.println();
            System.out.println(g0.getAdjacencyInfo());
            System.out.println();

            VentanaEjemplo v = new VentanaEjemplo("Proyecto II", g0);

            v.init();

            v.addRoute(g0.getVertex(36), g0.getVertex(14));
            v.addRoute(g0.getVertex(12), g0.getVertex(6));
            v.addRoute(g0.getVertex(6), g0.getVertex(4));
            v.addRoute(g0.getVertex(26), g0.getVertex(10));
            v.addRoute(g0.getVertex(10), g0.getVertex(23));

            SwingUtilities.invokeLater(() -> {

            });
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
        }
    }

    public Graph<Integer, Double> crearPuntos() {
        Graph<Integer, Double> g0 = new Graph<>();
        
        g0.setBackground("src\\images\\HerediaS.png");
        
        g0.add(0, new Point2D.Float(100, 75));
        g0.add(1, new Point2D.Float(220, 88));
        g0.add(2, new Point2D.Float(335, 99));
        g0.add(3, new Point2D.Float(463, 110));
        g0.add(4, new Point2D.Float(583, 10));
        g0.add(5, new Point2D.Float(698, 15));
        g0.add(6, new Point2D.Float(583, 117));
        g0.add(7, new Point2D.Float(698, 125));
        g0.add(8, new Point2D.Float(817, 27));
        g0.add(9, new Point2D.Float(818, 132));
        g0.add(10, new Point2D.Float(933, 73));
        g0.add(11, new Point2D.Float(929, 141));
        g0.add(12, new Point2D.Float(997, 152));
        g0.add(13, new Point2D.Float(1068, 137));
        g0.add(14, new Point2D.Float(1124, 118));
        g0.add(15, new Point2D.Float(100, 195));
        g0.add(16, new Point2D.Float(220, 208));
        g0.add(17, new Point2D.Float(335, 219));
        g0.add(18, new Point2D.Float(463, 230));
        g0.add(19, new Point2D.Float(583, 237));
        g0.add(20, new Point2D.Float(698, 245));
        g0.add(21, new Point2D.Float(818, 255));
        g0.add(22, new Point2D.Float(935, 261));
        g0.add(23, new Point2D.Float(999, 248));
        g0.add(24, new Point2D.Float(1060, 288));
        g0.add(25, new Point2D.Float(1105, 332));
        g0.add(26, new Point2D.Float(1145, 226));
        g0.add(27, new Point2D.Float(100, 315));
        g0.add(28, new Point2D.Float(224, 325));
        g0.add(29, new Point2D.Float(339, 337));
        g0.add(30, new Point2D.Float(463, 350));
        g0.add(31, new Point2D.Float(583, 360));
        g0.add(32, new Point2D.Float(698, 372));
        g0.add(33, new Point2D.Float(818, 384));
        g0.add(34, new Point2D.Float(100, 435));
        g0.add(35, new Point2D.Float(224, 445));
        g0.add(36, new Point2D.Float(339, 457));
        g0.add(37, new Point2D.Float(463, 470));
        g0.add(38, new Point2D.Float(583, 480));
        g0.add(39, new Point2D.Float(698, 492));
        g0.add(40, new Point2D.Float(818, 504));
        g0.add(41, new Point2D.Float(100, 555));
        g0.add(42, new Point2D.Float(224, 565));
        g0.add(43, new Point2D.Float(339, 577));
        g0.add(44, new Point2D.Float(463, 590));
        g0.add(45, new Point2D.Float(583, 600));
        g0.add(46, new Point2D.Float(693, 612));
        g0.add(47, new Point2D.Float(823, 620));

        g0.add(0, 15, 2.0);
        g0.add(0, 1, 2.0);
        g0.add(1, 16, 2.0);
        g0.add(1, 2, 2.0);
        g0.add(2, 3, 2.0);
        g0.add(3, 6, 2.0);
        g0.add(4, 6, 3.0);
        g0.add(5, 4, 3.0);
        g0.add(6, 19, 3.0);
        g0.add(7, 6, 2.0);
        g0.add(7, 20, 2.0);
        g0.add(7, 5, 2.0);
        g0.add(8, 5, 2.0);
        g0.add(9, 8, 2.0);
        g0.add(9, 7, 2.0);
        g0.add(9, 11, 3.0);
        g0.add(10, 11, 4.0);
        g0.add(11, 22, 2.0);
        g0.add(11, 12, 3.0);
        g0.add(12, 13, 2.0);
        g0.add(12, 23, 2.0);
        g0.add(13, 14, 2.0);
        g0.add(13, 24, 2.0);
        g0.add(14, 26, 3.0);
        g0.add(15, 27, 3.0);
        g0.add(16, 28, 3.0);
        g0.add(16, 15, 2.0);
        g0.add(17, 16, 2.0);
        g0.add(17, 2, 2.0);
        g0.add(18, 17, 3.0);
        g0.add(18, 3, 2.0);
        g0.add(19, 31, 3.0);
        g0.add(19, 18, 3.0);
        g0.add(20, 19, 2.0);
        g0.add(21, 20, 3.0);
        g0.add(21, 9, 3.0);
        g0.add(22, 21, 4.0);
        g0.add(23, 22, 3.0);
        g0.add(24, 23, 2.0);
        g0.add(25, 24, 2.0);
        g0.add(26, 25, 5.0);
        g0.add(27, 28, 2.0);
        g0.add(28, 29, 2.0);
        g0.add(28, 35, 3.0);
        g0.add(29, 30, 3.0);
        g0.add(29, 17, 2.0);
        g0.add(30, 31, 3.0);
        g0.add(30, 18, 2.0);
        g0.add(31, 32, 3.0);
        g0.add(32, 33, 2.0);
        g0.add(32, 39, 3.0);
        g0.add(33, 21, 3.0);
        g0.add(34, 41, 3.0);
        g0.add(35, 34, 3.0);
        g0.add(36, 29, 3.0);
        g0.add(36, 35, 3.0);
        g0.add(37, 36, 3.0);
        g0.add(37, 30, 3.0);
        g0.add(38, 37, 3.0);
        g0.add(38, 31, 2.0);
        g0.add(39, 38, 3.0);
        g0.add(39, 46, 3.0);
        g0.add(40, 33, 3.0);
        g0.add(40, 39, 3.0);
        g0.add(41, 42, 2.0);
        g0.add(42, 43, 2.0);
        g0.add(43, 44, 2.0);
        g0.add(43, 36, 3.0);
        g0.add(44, 45, 3.0);
        g0.add(44, 37, 2.0);
        g0.add(45, 46, 3.0);
        g0.add(45, 38, 2.0);
        g0.add(46, 47, 3.0);
        g0.add(47, 40, 3.0);

        return g0;
    }

}
