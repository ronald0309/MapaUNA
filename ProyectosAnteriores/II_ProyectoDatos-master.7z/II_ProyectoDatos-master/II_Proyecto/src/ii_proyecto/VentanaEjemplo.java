package ii_proyecto;

import controller.Utiles;
import files.Archivo;
import graphs.GVertex;
import graphs.Graph;
import graphs.view.GraphPanel;
import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;

public class VentanaEjemplo<V, W> extends JFrame implements ActionListener {

    public VentanaEjemplo(String titulo, Graph<V, W> g)
            throws HeadlessException {
        super(titulo);
        this.g = g;
        this.archivo = new JMenu("Archivo");
        this.abrir = new JMenuItem("Abrir");
        this.guardar = new JMenuItem("Guardar");
        this.menuBar = new JMenuBar();
        this.abrir.addActionListener(this);
        this.guardar.addActionListener(this);
        configurar();
    }

    private void configurar() {
        ajustarComponentes(getContentPane());
        setResizable(true);
        setSize(1200, 720);
        this.setResizable(false);
        setLocationRelativeTo(null);

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {

            @Override
            public void windowClosing(WindowEvent e) {
                g.setActive(false);
                System.exit(0);
            }
        });
    }

    private void ajustarComponentes(Container c) {
        c.setLayout(new BorderLayout());
        JPanel panelControl = new JPanel();
        panelControl.setLayout(new FlowLayout(FlowLayout.LEFT));
        panelControl.add(controlActivo = new JCheckBox("Activo"));
        panelControl.setBorder(BorderFactory.createEmptyBorder(4, 4, 2, 2));
        c.add(BorderLayout.PAGE_START, panelControl);
        c.add(BorderLayout.CENTER, panelPrincipal = new GraphPanel<>(g));
        panelPrincipal.setVentanaEjemplo(this);

        controlActivo.addActionListener(
                (ActionEvent evt) -> {
                    cambiarActivo(controlActivo.isSelected());
                }
        );

        this.setJMenuBar(this.menuBar);
        menuBar.add(archivo);
        archivo.add(abrir);
        archivo.add(guardar);

    }

    public void addRoute(GVertex<V> partida, GVertex<V> destino) {
        g.init(partida, destino);
    }

    public void init() {
        setVisible(true);
        panelPrincipal.init();
        controlActivo.setSelected(panelPrincipal.isActive());
    }

    public void cambiarActivo(boolean estado) {
        panelPrincipal.setActive(estado);
    }

    private GraphPanel<V, W> panelPrincipal;
    private JCheckBox controlActivo;
    private JMenuBar menuBar;
    private JMenu archivo;
    private JMenuItem abrir, guardar;

    private final Graph<V, W> g;

    /* Graph<Object, Object> */
    @Override
    public void actionPerformed(ActionEvent e) {
        switch (e.getActionCommand()) {
            case "Abrir":
                //codigo para abrir un archivo xml
                JFileChooser chooser = new JFileChooser();
                FileNameExtensionFilter filtro = new FileNameExtensionFilter("*.XML", "xml");
                chooser.setFileFilter(filtro);

                if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                    File file = chooser.getSelectedFile();
                    String filename = file.getAbsolutePath();

                    try {
                        Graph<Integer, Double> g0;
                        g0 = Archivo.<Integer, Double>read(
                                new Utiles<>(
                                        (x) -> Integer.valueOf(x),
                                        (Exception ex) -> ex.getMessage()
                                ),
                                new Utiles<>(
                                        (x) -> Double.valueOf(x),
                                        (Exception ex) -> ex.getMessage()
                                ),
                                 filename
                        );
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, ex.getMessage(), null, JOptionPane.ERROR_MESSAGE);
                    }
                }

                break;

            case "Guardar":
                JFileChooser chooserSave = new JFileChooser();

                if (chooserSave.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
                    File fileSave = chooserSave.getSelectedFile();
                    String route = fileSave.getAbsolutePath();

                    try {
                        Archivo.save(g, route);
                        JOptionPane.showMessageDialog(this, "Se ha guardado el archivo correctamente.", null, JOptionPane.INFORMATION_MESSAGE);
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this, ex.getMessage(), null, JOptionPane.ERROR_MESSAGE);
                    }
                }

                break;
        }
    }
}
