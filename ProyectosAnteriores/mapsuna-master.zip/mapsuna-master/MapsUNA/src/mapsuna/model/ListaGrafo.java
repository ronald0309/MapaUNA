package mapsuna.model;

/**
 *
 * @author Jona
 */
public class ListaGrafo {
    private String id;
    private boolean visitado;

}
